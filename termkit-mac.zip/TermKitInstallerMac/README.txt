TermKit for macOS
==================

TermKit is a command-line tool that provides a categorized, interactive menu
of useful system commands (e.g. for networking, processes, users, file operations).

Instead of executing the command directly, TermKit copies the selected command
to your clipboard so you can review and paste it manually.

Installation
------------

1. Unzip the TermKitInstallerMac.zip file.

2. Open the extracted folder. You will see a file called `setup.command`.

3. Double-click `setup.command` to run the installer.

Note: On first run, macOS may block the file with a warning:
> "setup.command can't be opened because it is from an unidentified developer."

To run it anyway:

a) Open `System Preferences` → `Security & Privacy` → `General`  
b) You will see a message about `setup.command` being blocked  
c) Click "Open Anyway"  
d) Confirm the prompt

After this, the installer will run and:

- Install TermKit to `~/.termkit`
- Install the required Python package `textual` (if needed)
- Create a terminal command: `tk`

Using TermKit
-------------

After installation, open any terminal and type:

    tk

You will see the interactive menu. Navigate with arrow keys and press Enter to
copy a command to your clipboard.

Requirements
------------

- macOS 11 or later
- Python 3.10+ must be installed (via Homebrew or official installer)
